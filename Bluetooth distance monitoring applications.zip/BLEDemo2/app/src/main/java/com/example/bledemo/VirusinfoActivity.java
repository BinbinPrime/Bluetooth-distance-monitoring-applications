package com.example.bledemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;

public class VirusinfoActivity extends AppCompatActivity {

    private Button mBtn6, mBtn7;
    private CheckBox mCB1, mCB2, mCB3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_virusinfo);

        mBtn7 = findViewById(R.id.Btn7);
        mBtn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转演示界面
                Intent intent = new Intent(VirusinfoActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
        mBtn6 = findViewById(R.id.Btn6);
        mBtn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转演示界面
                Intent intent = new Intent(VirusinfoActivity.this, VirusExActivity.class);
                startActivity(intent);
            }
        });

        mCB1 = findViewById(R.id.cb1);
        mCB1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Toast.makeText(VirusinfoActivity.this,isChecked?"Please contact your doctor":"Your body is all right",Toast.LENGTH_LONG).show();
            }
        });

        mCB2 = findViewById(R.id.cb2);
        mCB2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Toast.makeText(VirusinfoActivity.this,isChecked?"Please go to the hospital":"Your body is all right",Toast.LENGTH_LONG).show();
            }
        });

        mCB3 = findViewById(R.id.cb3);
        mCB3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Toast.makeText(VirusinfoActivity.this,isChecked?"You may be infected":"Your body is all right",Toast.LENGTH_LONG).show();
            }
        });
    }
}