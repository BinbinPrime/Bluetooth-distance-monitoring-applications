package com.example.bledemo;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;


public class PermissionsChecker {
    private final Context mContext;

    public PermissionsChecker(Context context) {
        mContext = context.getApplicationContext();
    }

    // Determining the set of permissions
    @RequiresApi(api = Build.VERSION_CODES.O)
    public boolean lacksPermissions(String... permissions) {
//        if(Build.VERSION.SDK_INT<23){
//            PackageManager pm =mContext.getPackageManager();
//            for (String permission : permissions) {
//                boolean flag = (PackageManager.PERMISSION_GRANTED ==
//                        mContext.checkCallingOrSelfPermission(permission));
//                if (!flag) {
//                    return true;
//                }
//            }
//        }else{
        for (String permission : permissions) {
            if (lacksPermission(permission)) {
                return true;
            }
        }
//        }
        return false;
    }

    // Determining if permissions are missing
    @RequiresApi(api = Build.VERSION_CODES.O)
    private boolean lacksPermission(String permission) {
        if(permission.equals(Manifest.permission.REQUEST_INSTALL_PACKAGES)){
            return !mContext.getPackageManager().canRequestPackageInstalls();
        }
        return ContextCompat.checkSelfPermission(mContext, permission) ==
                PackageManager.PERMISSION_DENIED;
    }
}