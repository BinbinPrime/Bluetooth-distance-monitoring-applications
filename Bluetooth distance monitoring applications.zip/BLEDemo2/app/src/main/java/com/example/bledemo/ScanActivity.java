package com.example.bledemo;

import android.Manifest;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.inuker.bluetooth.library.BluetoothClient;
import com.inuker.bluetooth.library.beacon.Beacon;
import com.inuker.bluetooth.library.connect.listener.BluetoothStateListener;
import com.inuker.bluetooth.library.search.SearchRequest;
import com.inuker.bluetooth.library.search.SearchResult;
import com.inuker.bluetooth.library.search.response.SearchResponse;
import com.inuker.bluetooth.library.utils.BluetoothLog;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class ScanActivity extends AppCompatActivity {

    private Button mScan;
    private ListView mListView;
    private BLEDeviceListAdapter mListAdapter;
    private BluetoothClient mClient;
    private List<SearchResult> mDeviceList;
    private Timer timer;
    private Button mBtn16;

    private final static int REQUEST_CODE = 10; // Request Code
    // All permissions required
    private String[] PERMISSIONS = new String[]{
            Manifest.permission.BLUETOOTH,
            Manifest.permission.BLUETOOTH_ADMIN,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
    };

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);

        mBtn16 = findViewById(R.id.Btn16);
        mBtn16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转演示界面
                Intent intent = new Intent(ScanActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        findView();
        initData();

        mClient = new BluetoothClient(getApplicationContext());

        mClient.registerBluetoothStateListener(mBluetoothStateListener);

        checkPermission();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mClient.unregisterBluetoothStateListener(mBluetoothStateListener);
    }


    public void findView(){
        mScan = findViewById(R.id.scan);
        mListView = findViewById(R.id.list);

        mScan.setOnClickListener(view -> {
            boolean isOpen = mClient.isBluetoothOpened();
            if(isOpen){
                startScan();
                timerSchedule();
            }
        });
    }

    public void initData(){
        mDeviceList = new ArrayList<>();
        if(mListAdapter == null){
            mListAdapter = new BLEDeviceListAdapter(getApplicationContext(),mDeviceList);
            mListView.setAdapter(mListAdapter);
        }

    }

    private final BluetoothStateListener mBluetoothStateListener = new BluetoothStateListener() {
        @Override
        public void onBluetoothStateChanged(boolean openOrClosed) {

        }
    };

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void checkPermission() {
        PermissionsChecker mPermissionsChecker = new PermissionsChecker(getApplicationContext());
        // If you are missing a permission, go to the permission configuration page
        if (mPermissionsChecker.lacksPermissions(PERMISSIONS)) {
            startPermissionsActivity();
        }
    }

    public void startPermissionsActivity() {
        Intent intent = new Intent(getApplicationContext(), PermissionsActivity.class);
        intent.putExtra(PermissionsActivity.EXTRA_PERMISSIONS, PERMISSIONS);
        startActivityForResult(intent, REQUEST_CODE);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_CODE:// On rejection, page closed, primary rights missing, unable to run
                if (resultCode == PermissionsActivity.PERMISSIONS_DENIED) {

                } else {
//                    mHandler.sendEmptyMessage(2000);
                }
                break;
        }
    }

    private void startScan(){
        ThreadUtils.exec(() -> {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mDeviceList.clear();
                    SearchRequest request = new SearchRequest.Builder()
                            .searchBluetoothLeDevice(3000, 3)   // First sweep BLE device 3 times for 3s each
                            .searchBluetoothClassicDevice(5000) // Re-scan Classic Bluetooth 5s
                            .searchBluetoothLeDevice(2000)  // Re-scan BLE devices for 2s
                            .build();
                    mClient.search(request, new SearchResponse() {
                        @Override
                        public void onSearchStarted() {
                            BluetoothLog.v("------woshi start");
                        }

                        @Override
                        public void onDeviceFounded(SearchResult device) {
                            if(mDeviceList.size() == 0){
                                mDeviceList.add(device);
                            } else {
                                boolean flag = false;
                                for (int i = 0; i < mDeviceList.size(); i++) {
                                    if (mDeviceList.get(i).getAddress().equals(device.getAddress())) {
                                        mDeviceList.get(i).rssi = device.rssi;
                                        flag = true;
                                        break;
                                    }
                                }
                                if(!flag){
                                    mDeviceList.add(device);
                                }
                            }
                            mListAdapter.setmDeviceList(mDeviceList);
                            mListAdapter.notifyDataSetChanged();
                            Beacon beacon = new Beacon(device.scanRecord);
                            BluetoothLog.v(String.format("beacon for %s\n%s\n%s", device.getAddress(), device.rssi, device.getName()));
                        }//The output is on the list

                        @Override
                        public void onSearchStopped() {

                        }

                        @Override
                        public void onSearchCanceled() {

                        }
                    });
                }
            });
        });
    }

    private void timerSchedule(){
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                startScan();
            }
        },18000,20000);
    }

//    private void readRssi(boolean flag){
//        while (flag){
//            ThreadUtils.exec(() -> {
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        for(int i = 0; i < mDeviceList.size();) {
//                            mClient.readRssi(mDeviceList.get(i).getAddress(), new BleReadRssiResponse() {
//                                @Override
//                                public void onResponse(int code, Integer rssi) {
//                                    if (code == REQUEST_SUCCESS) {
//                                        mDeviceList.get(i).rssi = rssi;
//                                        mListAdapter.setmDeviceList(mDeviceList);
//                                        mListAdapter.notifyDataSetChanged();
//                                        i++;
//                                    }
//                                }
//                            });
//                        }
//                    }
//                });
//            });
//        }
//    }

}