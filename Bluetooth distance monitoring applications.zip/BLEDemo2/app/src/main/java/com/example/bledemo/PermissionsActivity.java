package com.example.bledemo;

import android.Manifest;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;


public class PermissionsActivity extends AppCompatActivity {

    public static final int PERMISSIONS_GRANTED = 0; // Access authorization
    public static final int PERMISSIONS_DENIED = 1; // Permission denied

    private static final int PERMISSION_REQUEST_CODE = 0; // The parameters of the system rights management page
    private static final int REQUEST_CODE_APP_INSTALL = 1;
   public static String EXTRA_PERMISSIONS =
            "me.chunyu.clwang.permission.extra_permission"; // Authority parameters
    private static final String PACKAGE_URL_SCHEME = "package:"; // plan

    private boolean isRequireCheck; // Whether system permission checking is required

    // Start the public interface of the current permission page
    public static void startActivityForResult(Activity activity, int requestCode, String... permissions) {
        Intent intent = new Intent(activity, PermissionsActivity.class);
        intent.putExtra(EXTRA_PERMISSIONS, permissions);
        ActivityCompat.startActivityForResult(activity, intent, requestCode, null);
    }
    // Launch the public interface of the current permission page
    public static void startFragmentActivityForResult(Activity activity, int requestCode, String... permissions) {
//        Intent intent = new Intent(activity, PermissionsActivity.class);
//        intent.putExtra(EXTRA_PERMISSIONS, permissions);
//        startActivityForResult(intent, requestCode);
    }
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getIntent() == null || !getIntent().hasExtra(EXTRA_PERMISSIONS)) {
            throw new RuntimeException("PermissionsActivity need use static startActivityForResult method start!");
        }
        setContentView(R.layout.activity_permissions);

        isRequireCheck = true;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onResume() {
        super.onResume();
        if (isRequireCheck) {
            String[] permissions = getPermissions();
            if (new PermissionsChecker(this).lacksPermissions(permissions)) {
                requestPermissions(permissions); // Request permission
            } else {
                allPermissionsGranted(); // All permissions have been obtained
            }
        } else {
            isRequireCheck = true;
        }
    }

    // Return the passed permission parameter
    private String[] getPermissions() {
        return getIntent().getStringArrayExtra(EXTRA_PERMISSIONS);
    }

    // Request permission to be compatible with lower versions
    private void requestPermissions(String... permissions) {
        ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE);
    }

    // All permissions have been obtained
    private void allPermissionsGranted() {
        setResult(PERMISSIONS_GRANTED);
        finish();
    }

    /**
     * User rights processing,
     * If all permissions have been obtained, they will be passed.
     * If permissions are missing, the Dialog will be prompted.
     *
     * @param requestCode  Request Code
     * @param permissions  Permission
     * @param grantResults Result
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == REQUEST_CODE_APP_INSTALL){
            if(getPackageManager().canRequestPackageInstalls()){
                if(hasAllPermissionsGranted(grantResults)){
                    isRequireCheck = true;
                    allPermissionsGranted();
                }else{
                    isRequireCheck = false;
                    showMissingPermissionDialog();
                }
            }else{
                showMissingUnknownAppsPermissionDialog();
            }
        }
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if( hasAllPermissionsGranted(grantResults)){
                isRequireCheck = true;
                allPermissionsGranted();
            }else{
                isRequireCheck = false;
                boolean flag=false;
                for (String permission : permissions) {
                    if(permission.equals(Manifest.permission.REQUEST_INSTALL_PACKAGES)){
                        flag=true;
                    }
                }
                if(Build.VERSION.SDK_INT>=26&&!getPackageManager().canRequestPackageInstalls()&&flag){
                    showMissingUnknownAppsPermissionDialog();
                }else {
                    showMissingPermissionDialog();
                }
            }
        }
    }

    // Contains all permissions
    private boolean hasAllPermissionsGranted(@NonNull int[] grantResults) {
        for (int grantResult : grantResults) {
            if (grantResult == PackageManager.PERMISSION_DENIED) {
                return false;
            }
        }
        return true;
    }

    // Display missing permission prompt
    private void showMissingPermissionDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(PermissionsActivity.this);
        builder.setTitle(R.string.help);
        builder.setMessage(R.string.string_help_text);

        // Reject, Exit application
        builder.setNegativeButton(R.string.quit, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                setResult(PERMISSIONS_DENIED);
                finish();
            }
        });

        builder.setPositiveButton(R.string.settings, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startAppSettings();
            }
        });

        builder.show();
    }

    // Display missing permission prompt
    private void showMissingUnknownAppsPermissionDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(PermissionsActivity.this);
        builder.setTitle(R.string.help);
        builder.setMessage(R.string.string_help_text);

        // Reject, Exit application
        builder.setNegativeButton(R.string.quit, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                setResult(PERMISSIONS_DENIED);
                finish();
            }
        });

        builder.setPositiveButton(R.string.settings, new DialogInterface.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startUnknownAppsSettings();
            }
        });

        builder.show();
    }

    // Start application setting
    private void startAppSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(Uri.parse(PACKAGE_URL_SCHEME + getPackageName()));
        startActivity(intent);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void startUnknownAppsSettings(){
        Intent intent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES);
        intent.setData(Uri.parse(PACKAGE_URL_SCHEME + getPackageName()));
        startActivityForResult(intent,REQUEST_CODE_APP_INSTALL);
    }
}