package com.example.bledemo;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.inuker.bluetooth.library.search.SearchResult;

import java.io.IOException;
import java.util.List;

class BLEDeviceListAdapter extends BaseAdapter{

    private Context mContext;
    private List<SearchResult> mDeviceList;
    private boolean mFirstFlag = true;
    private MediaPlayer mMediaPlayer;

    public BLEDeviceListAdapter(Context context, List<SearchResult> deviceList){
        this.mContext = context;
        this.mDeviceList = deviceList;
        if(mFirstFlag){
            mFirstFlag = false;
            mMediaPlayer=MediaPlayer.create(mContext, R.raw.beep);
            mMediaPlayer.setLooping(true);
        }
    }

    public void setmDeviceList(List<SearchResult> deviceList) {
        this.mDeviceList = deviceList;
    }

    @Override
    public int getCount() {
        return mDeviceList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public int getItemViewType(int position) {
        return 1;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;

        if (convertView == null) {
            holder=new ViewHolder();
            convertView= LayoutInflater.from(mContext).inflate(R.layout.device_info_layout, null);
            holder.deviceBg = convertView.findViewById(R.id.bg);
            holder.deviceName = convertView.findViewById(R.id.device_name);
            holder.deviceMac = convertView.findViewById(R.id.device_mac);
            holder.deviceRrs = convertView.findViewById(R.id.device_rrs);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        if(mDeviceList.get(position).getName().equals("NULL")){
            holder.deviceName.setText("Unnamed device");//Handling of unknown equipment
        } else {
            holder.deviceName.setText(mDeviceList.get(position).getName());
        }
        holder.deviceMac.setText(mDeviceList.get(position).getAddress());
        holder.deviceRrs.setText(mDeviceList.get(position).rssi + "  db");
        if(mDeviceList.get(position).rssi < -90){
            holder.deviceBg.setBackgroundColor(Color.RED);//Signal strength above 90 will turn the device display red
            playSound(true);//Alarm triggering
        } else {
            holder.deviceBg.setBackgroundColor(Color.WHITE);//Signal strength less than 90 will turn the device display white
            playSound(false);
        }

        return convertView;
    }
    class ViewHolder {
        ConstraintLayout deviceBg;
        TextView deviceName;
        TextView deviceMac;
        TextView deviceRrs;
    }

    private void playSound(boolean flag){
        if(flag) {
            mMediaPlayer.start();
            try {
                Thread.sleep(1500);//Duration of alarms
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            mMediaPlayer.pause();
        } else {
        }
    }
}
