package com.example.bledemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MyTimer extends AppCompatActivity {

    private EditText mET1;
    private TextView mtv49;
    private Button mBtn11, mBtn13, mBtn14,mBtn15;

    private CountDownTimer mCountDownTimer;
    private boolean mTimerRunning;

    private long mStartTimeInMillis;
    private long mTimerLeftInMillis;
    private long mEndTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_timer);

        mtv49 = findViewById(R.id.tv49);
        mBtn11 = findViewById(R.id.Btn11);
        mBtn13 = findViewById(R.id.Btn13);
        mBtn14 = findViewById(R.id.Btn14);
        mET1 = findViewById(R.id.et1);

        mBtn15 = findViewById(R.id.Btn15);
        mBtn15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转演示界面
                Intent intent = new Intent(MyTimer.this, MainActivity.class);
                startActivity(intent);
            }
        });

        mBtn14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetTimer();
            }
        });

        mBtn13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input = mET1.getText().toString();
                if (input.length() == 0) {
                    Toast.makeText(MyTimer.this, "Field can't be empty", Toast.LENGTH_SHORT).show();
                    return;
                }

                long millisInput = Long.parseLong(input) * 60000;
                if (millisInput == 0) {
                    Toast.makeText(MyTimer.this, "Please enter a positive number", Toast.LENGTH_SHORT).show();
                    return;
                }
                setTimer(millisInput);
                mET1.setText("");
            }
        });

        mBtn11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mTimerRunning) {
                    pauseTimer();
                } else {
                    startTimer();
                }
            }
        });
    }
    private void setTimer(long milliseconds) {
        mStartTimeInMillis = milliseconds;
        resetTimer();
        closeKeyboard();
    }

    public void startTimer() {
        mEndTime = System.currentTimeMillis() + mTimerLeftInMillis;

        mCountDownTimer = new CountDownTimer(mTimerLeftInMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                mTimerLeftInMillis = millisUntilFinished;
                updateCountDownText();
            }

            @Override
            public void onFinish() {
                mTimerRunning = false;
                updateButtons();
            }
        }.start();

        mTimerRunning = true;
        updateButtons();
    }

    public void pauseTimer() {
        mCountDownTimer.cancel();
        mTimerRunning = false;
        updateButtons();
    }

    public void resetTimer() {
        mTimerLeftInMillis = mStartTimeInMillis;
        updateCountDownText();
        updateButtons();
    }

    private void updateCountDownText() {
        int hours = (int) (mTimerLeftInMillis / 1000) / 3600;
        int minutes = (int) ((mTimerLeftInMillis / 1000) % 3600) / 60;
        int seconds = (int) (mTimerLeftInMillis / 1000) % 60;
//Set the interchangeability of hours, minutes and seconds
        String timeLeftFormatted;
        if (hours > 0) {
            timeLeftFormatted = String.format(Locale.getDefault(),
                    "%d:%02d:%02d", hours, minutes, seconds);
        } else {
            timeLeftFormatted = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
        }
//Set the time of presentation
        mtv49.setText(timeLeftFormatted);
    }

    private void updateButtons() {
        if (mTimerRunning) {
            mET1.setVisibility(View.INVISIBLE);
            mBtn13.setVisibility(View.INVISIBLE);
            mBtn14.setVisibility(View.INVISIBLE);
            mBtn11.setText("pause");//Change of button status after the countdown has started
        } else {
            mET1.setVisibility(View.VISIBLE);
            mBtn13.setVisibility(View.VISIBLE);
            mBtn11.setText("Start");//Change of button status after the countdown has paused

            if (mTimerLeftInMillis < 1000) {
                mBtn11.setVisibility(View.INVISIBLE);
            } else {
                mBtn11.setVisibility(View.VISIBLE);
            }//Button change at the end of the timer

            if (mTimerLeftInMillis < mStartTimeInMillis) {
                mBtn14.setVisibility(View.VISIBLE);
            } else {
                mBtn14.setVisibility(View.INVISIBLE);
            }//Button changes in timing
        }
    }

    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();

        SharedPreferences prefs = getSharedPreferences("prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.putLong("startTimeInMillis", mStartTimeInMillis);
        editor.putLong("millisLeft", mTimerLeftInMillis);
        editor.putBoolean("timerRunning", mTimerRunning);
        editor.putLong("endTime", mEndTime);

        editor.apply();

//        if (mtv49 != null){
//            mtv49.cancel();
//        }
    }

    @Override
    protected void onStart() {
        super.onStart();

        SharedPreferences prefs = getSharedPreferences("prefs", MODE_PRIVATE);

        mStartTimeInMillis = prefs.getLong("startTimeInMillis", 600000);
        mTimerLeftInMillis = prefs.getLong("millisLeft", mStartTimeInMillis);
        mTimerRunning = prefs.getBoolean("TimerRunning", false);

        updateCountDownText();
        updateButtons();
    }
}