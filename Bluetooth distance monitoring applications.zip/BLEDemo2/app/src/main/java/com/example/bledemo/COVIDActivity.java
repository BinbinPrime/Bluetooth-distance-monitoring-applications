package com.example.bledemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class COVIDActivity extends AppCompatActivity {

    private TextViewBorder mtv8;
    private TextView mtv9,mtv18;
    private Button mBtn8;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c_o_v_i_d);

        setContentView(R.layout.activity_c_o_v_i_d);
        mtv8 = (TextViewBorder) findViewById(R.id.tv8);

        //边框颜色
        mtv8.setBorderColor(getResources().getColor(R.color.black));
        //字体颜色
        mtv8.setTextColor(getResources().getColor(R.color.black));

        mtv9 = findViewById(R.id.tv9);
        mtv9.setMovementMethod(LinkMovementMethod.getInstance());

        mtv18 = findViewById(R.id.tv18);
        mtv18.setMovementMethod(LinkMovementMethod.getInstance());

        mBtn8 = findViewById(R.id.Btn8);
        mBtn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转演示界面
                Intent intent = new Intent(COVIDActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }
}