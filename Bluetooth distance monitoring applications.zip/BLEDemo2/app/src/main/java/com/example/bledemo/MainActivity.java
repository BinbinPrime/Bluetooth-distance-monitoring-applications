package com.example.bledemo;

import android.Manifest;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button mBtn1,mBtn2,mBtn3,mBtn4,mBtn5,mBtn12;
    private final static int REQUEST_CODE = 10; // Request Code
    // All permissions required
    private String[] PERMISSIONS = new String[]{
            Manifest.permission.BLUETOOTH,
            Manifest.permission.BLUETOOTH_ADMIN,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mBtn1 = findViewById(R.id.Btn1);
        mBtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Skip to aim screen
                Intent intent = new Intent(MainActivity.this,COVIDActivity.class);
                startActivity(intent);
            }
        });

        mBtn2 = findViewById(R.id.Btn2);
        mBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转演示界面
                Intent intent = new Intent(MainActivity.this,VirusinfoActivity.class);
                startActivity(intent);
            }
        });

        mBtn4 = findViewById(R.id.Btn4);
        mBtn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转演示界面
                Intent intent = new Intent(MainActivity.this,PolicyActivity.class);
                startActivity(intent);
            }
        });

        mBtn5 = findViewById(R.id.Btn5);
        mBtn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转演示界面
                Intent intent = new Intent(MainActivity.this,MapsActivity.class);
                startActivity(intent);
            }
        });

        mBtn12 = findViewById(R.id.Btn12);
        mBtn12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转演示界面
                Intent intent = new Intent(MainActivity.this,MyTimer.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.open).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkPermission();
            }
        });//Bluetooth button click events

        findViewById(R.id.scan).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this,ScanActivity.class);
                startActivity(intent);
            }
        });

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private void checkPermission() {
        PermissionsChecker mPermissionsChecker = new PermissionsChecker(getApplicationContext());
        // If you are missing a permission, go to the permission configuration page
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mPermissionsChecker.lacksPermissions(PERMISSIONS)) {
                startPermissionsActivity();
            }else {
                findViewById(R.id.scan).setVisibility(View.VISIBLE);
            }
        }
    }

    public void startPermissionsActivity() {
        Intent intent = new Intent(getApplicationContext(), PermissionsActivity.class);
        intent.putExtra(PermissionsActivity.EXTRA_PERMISSIONS, PERMISSIONS);
        startActivityForResult(intent, REQUEST_CODE);//open bluetooth
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_CODE:// On rejection, page closed, primary rights missing, unable to run
                if (resultCode == PermissionsActivity.PERMISSIONS_DENIED) {

                } else {
//                    mHandler.sendEmptyMessage(2000);
                    Toast.makeText(MainActivity.this,"Click into interface",Toast.LENGTH_SHORT).show();
                }//error report
                break;
        }
    }


}