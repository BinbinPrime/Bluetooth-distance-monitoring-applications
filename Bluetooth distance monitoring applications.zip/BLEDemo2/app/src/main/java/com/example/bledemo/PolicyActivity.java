package com.example.bledemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class PolicyActivity extends AppCompatActivity {

    private TextView mtv21,mtv23,mtv25,mtv27,mtv29,mtv31,mtv33,mtv35,mtv37,mtv39;
    private Button mBtn9;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_policy);

        mtv21 = findViewById(R.id.tv21);
        mtv21.setMovementMethod(LinkMovementMethod.getInstance());

        mtv23 = findViewById(R.id.tv23);
        mtv23.setMovementMethod(LinkMovementMethod.getInstance());

        mtv25 = findViewById(R.id.tv25);
        mtv25.setMovementMethod(LinkMovementMethod.getInstance());

        mtv27 = findViewById(R.id.tv27);
        mtv27.setMovementMethod(LinkMovementMethod.getInstance());

        mtv29 = findViewById(R.id.tv29);
        mtv29.setMovementMethod(LinkMovementMethod.getInstance());

        mtv31 = findViewById(R.id.tv31);
        mtv31.setMovementMethod(LinkMovementMethod.getInstance());

        mtv33 = findViewById(R.id.tv33);
        mtv33.setMovementMethod(LinkMovementMethod.getInstance());

        mtv35 = findViewById(R.id.tv35);
        mtv35.setMovementMethod(LinkMovementMethod.getInstance());

        mtv37 = findViewById(R.id.tv37);
        mtv37.setMovementMethod(LinkMovementMethod.getInstance());

        mtv39 = findViewById(R.id.tv39);
        mtv39.setMovementMethod(LinkMovementMethod.getInstance());


        mBtn9 = findViewById(R.id.Btn9);
        mBtn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转演示界面
                Intent intent = new Intent(PolicyActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}