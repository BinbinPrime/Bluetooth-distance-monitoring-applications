package com.example.bledemo;

import android.os.SystemClock;
import java.util.LinkedList;
import java.util.NoSuchElementException;

public class ThreadUtils {
    public static boolean isRunning = true;
    private static ThreadUtils.ExcutorThread excutorThread = new ThreadUtils.ExcutorThread();

    public ThreadUtils() {
    }

    public static Thread execRunable(Runnable runnable) {
        final Thread thread = new Thread(runnable);
        thread.start();
        (new Thread() {
            public void run() {
                try {
                    Thread.sleep(10000L);
                } catch (Exception var2) {
                    var2.printStackTrace();
                }

                thread.interrupt();
            }
        }).start();
        return thread;
    }

    public static void exec(Runnable runnable) {
        try {
            if (!excutorThread.isAlive()) {
                excutorThread.start();
            }
        } catch (Exception var2) {
            excutorThread = new ThreadUtils.ExcutorThread();
            if (!excutorThread.isAlive()) {
                excutorThread.start();
            }
        }

        excutorThread.offer(runnable);
    }

    public static class ExcutorThread extends Thread {
        private static LinkedList<Runnable> runnableList = new LinkedList();

        public ExcutorThread() {
        }

        public void run() {
            while(ThreadUtils.isRunning) {
                try {
                    Runnable runnable;
                    try {
                        runnable = (Runnable)runnableList.getFirst();
                    } catch (NoSuchElementException var4) {
                        runnable = null;
                    } catch (Exception var5) {
                        runnable = null;
                    }

                    if (runnable == null) {
                        SystemClock.sleep(1000L);
                    } else {
                        Thread thread = new Thread(runnable);
                        thread.start();
                        int time = 0;

                        while(time < 50) {
                            ++time;
                            if (!thread.isAlive() || thread.isInterrupted()) {
                                break;
                            }

                            SystemClock.sleep(20L);
                        }

                        thread.interrupt();
                        runnableList.removeFirst();
                    }
                } catch (Exception var6) {
                }
            }

        }

        public void offer(Runnable runnable) {
            runnableList.addLast(runnable);
        }
    }
}
